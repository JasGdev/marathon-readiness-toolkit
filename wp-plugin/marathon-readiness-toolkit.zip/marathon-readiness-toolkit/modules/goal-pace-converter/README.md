**2. Goal Pace Converter (“What pace does my goal actually require?”)**  
- Inputs: goal time and race distance (10K / Half / Full)  
- Output: required pace per kilometer and mile  
- Purpose: establishes a concrete reference line for later comparisons  